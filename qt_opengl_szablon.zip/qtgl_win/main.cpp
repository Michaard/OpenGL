/*
**
**
** Przyklad bezposredniego wykorzystania biblioteki GLEW dla Windows
** umozliwiajacej w prosty sposob korzystanie z rozszerzen OpenGL
**
** Do kodu glownego musi byc dolaczony plik glew.c z definicjami
** oraz dwa pliki naglowkowe z katalogu .\GL\glew.h i .\GL\wglew.h
**
**
*/

#define GLEW_STATIC
//#define GLEW_NO_GLU
#include "GL/glew.h"

#include <QApplication>
#include <QGLWidget>
#include <QTimer>
#include <QKeyEvent>

typedef GLfloat vec3f[3];

class Widget : public QGLWidget
{
    GLuint vbo;
    GLfloat rtri = 0.0f;

    GLfloat xpos = 0;
    GLfloat ypos = 0;
    GLfloat zpos = 0;

protected:
    void initializeGL()
    {
        // Obowiazkowa inicjalizacja GLEWa
        GLenum err = glewInit();
        if (GLEW_OK != err)
        {
            qDebug((const char*)glewGetErrorString(err));
        }
        else
        {
            glEnable(GL_DEPTH_TEST);
            vec3f verts[3] = { {0,1,0}, {-1,-1,0}, {1,-1,0} };
            glGenBuffers(1, &vbo);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferData(GL_ARRAY_BUFFER, sizeof(verts), verts, GL_STATIC_DRAW);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
        }

        QTimer *timer = new QTimer(this);
        connect(timer, SIGNAL(timeout()), this, SLOT(update()));
        timer->start(100);
    }

    void paintGL()
    {
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); // czyszczenie buforow
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(-2.0,2.0,-2.0,2.0,5,-5.0);
        //gluPerspective(65,1,0.1,100);
        glTranslatef(0, 0, -3.0);
        glPushMatrix();
        glMatrixMode(GL_MODELVIEW);

        GLfloat xtrans = -xpos;
        GLfloat ytrans = ypos;
        GLfloat ztrans = -zpos;
        //GLfloat sceneroty = 360.0f - yrot;

        glLoadIdentity();
        //glRotatef(lookupdown, 1.0f, 0.0f, 0.0f);
        //glRotatef(sceneroty, 0.0f, 1.0f, 0.0f);
        glTranslatef(xtrans, ytrans, ztrans);

        glPushMatrix();

        glRotated(rtri,1.0f,1.0f,1.0f);
        glBegin(GL_TRIANGLES);
            glColor3f(1.0f,0.0f,0.0f);
            glVertex3f( 0.0f, 1.0f, 0.0f);
            glColor3f(0.0f,1.0f,0.0f);
            glVertex3f( -1.0f, -1.0f, 0.0f);
            glColor3f(0.0f,0.0f,1.0f);
            glVertex3f( 1.0f, -1.0f, 0.0f);
        glEnd();
        glPopMatrix();
        glPopMatrix();


        /*
        glColor3f(1,0,0);
        glEnableClientState(GL_VERTEX_ARRAY);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glVertexPointer(3, GL_FLOAT, 0, 0);
            glBindBuffer(GL_ARRAY_BUFFER, 0);
            glDrawArrays(GL_TRIANGLES, 0, 3);
        glDisableClientState(GL_VERTEX_ARRAY);
        */
        rtri+=2.0f;
        if(rtri>=360.0)
            rtri = 0.0f;


    }

    void resizeGL(int w, int h)
    {
        glViewport(0,0,w,h);
    }

    void keyPressEvent(QKeyEvent *event) {

        switch (event->key()) {
        case Qt::Key_Escape:
            close();
            break;
        case Qt::Key_F1:
            setWindowState(windowState() ^ Qt::WindowFullScreen);
            break;
        default:
            QGLWidget::keyPressEvent(event);
        case Qt::Key_Left:
            xpos-=0.1;
            break;
        case Qt::Key_Right:
            xpos+=0.1;
            break;
        case Qt::Key_Up:
            zpos-=0.5;
            break;
        case Qt::Key_Down:
            zpos+=0.5;
            break;

        }
    }
};

int main(int argc, char* argv[])
{
    QApplication app(argc, argv);
    Widget w;
    w.show();
    return app.exec();
}
